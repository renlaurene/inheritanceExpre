package medicalbilling;

public class LabBill extends MedicalBill{
	
	private double technicianFee; 
	private double laboratoryFee; 

	public LabBill(String patientChartNum, double technicianFee, double laboratoryFee)
		throws IllegalArgumentException {
		super(patientChartNum);
	}
	
	public double getTechnicianFee(){
		return technicianFee;
	}
	
	public void setTechnicianFee(double technicianFee){
		this.technicianFee = technicianFee; 
	}
	
	public double getLaboratoryFee(){
		return laboratoryFee; 
	}
	
	public void setLaboratoryFee(double laboratoryFee){
		this.laboratoryFee = laboratoryFee; 
	}

	@Override
	public String print(){
		return "data member " + getLaboratoryFee() + " another one " + getTechnicianFee();
	}
}
