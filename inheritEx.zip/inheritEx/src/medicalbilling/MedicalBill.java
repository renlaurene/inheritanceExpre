package medicalbilling; 

public class MedicalBill {
	
	private String patientChartNum;
	private double billAmount; 
	protected double amountPaid; 
	int visitLength;  
	
	public MedicalBill(String patientChartNum){
			//throws IllegalArgumentException{
		super();
		String numRegex = "[0-9]+";
		String alphaRegex = ".*[a-zA-Z]+.*";
		
		String first3Char = patientChartNum.substring(0, Math.min(patientChartNum.length(), 3));
		String last4Char = patientChartNum.substring(patientChartNum.length()-4);
		
		if((first3Char.matches(alphaRegex)) && (last4Char.matches(numRegex)) && patientChartNum.length() == 7)
		{
			this.patientChartNum = patientChartNum; 
		}else{
			this.billAmount = 0.0; 
			//throw new IllegalArgumentException
			//("Patient Chart Numer needs to set to AAA000");
		}	 	
	}
	
	public double getBillAmount(){
		return billAmount; 
		
	}
	
	public void setBillAmount(double billAmount){
		this.billAmount = billAmount; 
    }
	
	public double getAmountPaid(){
		return amountPaid; 
		
	}
	
	public void setAmountPaid(double amountPaid){
		this.amountPaid = amountPaid;
	}	
	
	public String print(){
		return "data member " + getAmountPaid() + " another one " + getBillAmount();
	}
}






