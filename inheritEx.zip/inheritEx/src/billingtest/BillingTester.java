package billingtest;

import medicalbilling.DoctorBill;
import medicalbilling.LabBill;
import medicalbilling.MedicalBill;
import java.util.*; // needed to use the ArrayList class

public class BillingTester {

	public static void main(String[] args) {
		// MedicalBill bill;
		// bill = new MedicalBill("AAA0012");
		//
		// DoctorBill billDoc;
		// billDoc = new DoctorBill("AAA0012", null, 20);
		//
		// LabBill billLab;
		// billLab = new LabBill("AAA012", 0, 0);
		// System.out.println(billDoc.getBillAmount());
		// System.out.println(billLab.getBillAmount());
		MedicalBill myBills[];
		myBills = getBillingObjects(); // You wrote this function last week
		printBills(myBills); // The function you wrote in the step above
	}

	public static void printAmountsOwed() {

	}

	public static MedicalBill[] getBillingObjects() {
		MedicalBill listOfBills[];
		MedicalBill singleBill;

		listOfBills = new MedicalBill[4];
		singleBill = new LabBill("ZKS4455", 100.0, 25.50);
		singleBill.setAmountPaid(20);
		singleBill.setBillAmount(100);
		listOfBills[0] = singleBill;
		singleBill = new LabBill("ZYQ5841", 150.0, 15.50);
		listOfBills[1] = singleBill;
		listOfBills[2] = singleBill;
		listOfBills[3] = singleBill;
		// Repeat this process to fill up the array with LabBill and DoctorBill
		// objects
		return listOfBills;
	}

	public static void printAmountsOwed(MedicalBill listOfBills[]) {
		// Write this function
		double amountOwed = 0.0;
		// billOwed = BillAmount - Insurance company paid
		for (MedicalBill curBill : listOfBills) {
			amountOwed += curBill.getBillAmount() - curBill.getAmountPaid();
			// System.out.print("\n\n" + amountOwed);
			System.out.print("\n\nBill Amount is: " + curBill.getBillAmount());
			System.out.print("\n\nInsuranceCompany paid: " + curBill.getAmountPaid());
		}
		// print the amount owed on each bill in the array(total amount- amount
		// ins paid)
		// System.out.println(listOfBills);
		System.out.println(" \n\n The bill owed amount: " + amountOwed);
	}

	public static void printBills(MedicalBill listOfBills[]) {
		// Print each bill in the array of medical bills passed as a parameter
		for (int i = 0; i < listOfBills.length; i++) {
			System.out.println(listOfBills[i]);
		}
	}

	public static ArrayList getArrayListOfBills() {// ArrayList class tutorial
		ArrayList listOfBills = null;
		MedicalBill singleBill;
		// Instantiate an ArrayList and fill it with DoctorBill and LabBill
		// objects
		return listOfBills;
	}
	
	public static void assignChartNum(MedicalBill listOfBills[], String chartNum) {
		// Every MedicalBill in the array should be given the chart number chartNum

		}
}